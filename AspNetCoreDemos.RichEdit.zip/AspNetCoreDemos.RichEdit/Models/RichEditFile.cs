﻿namespace AspNetCoreDemos.RichEdit.Models
{
    public class RichEditFile
    {
        public int Id { get; set; }
        public byte[] Data { get; set; }
        public string fileName { get; set; }
    }
}
